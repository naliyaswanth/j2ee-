package jdbcProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQueryUsingType1 {

	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
		//1. loading type4 driver
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");	//argument-->type4 class name 

		
		//2. establishing connection
		Connection con=DriverManager.getConnection("jdbc:odbc:EMP");
		//thin is a vendor of oracle
		//2nd arg is username, 3rd is password
		
		
		//creating statement to hold the sql query
		Statement st= con.createStatement();
		
		
		//creating and executing sql statement
		ResultSet rset= st.executeQuery("select * from PersonalDetails");
		
		
		//processing the result set to access the values
		while(rset.next())
		{
			System.out.println("empId : "+rset.getInt(1));
			System.out.println("employee name : "+rset.getString(2));
			System.out.println("age : "+rset.getString(3));
		}
		
		
		//closing all objects
		rset.close();
		con.close();
	}

}
